import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:streams/helpers/constants.dart';
import 'package:streams/widgets/button.dart';
import 'package:streams/widgets/text_field.dart';
import 'package:google_fonts/google_fonts.dart';

class SignupScreen extends StatefulWidget {
  final Function()? onTap;
  const SignupScreen({super.key, required this.onTap});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passController = TextEditingController();
  final TextEditingController _confirmpassController = TextEditingController();

  void signUp() async {
    showDialog(
      context: context,
      builder: (context) {
        return Center(
          child: CircularProgressIndicator(
            color: Theme.of(context).colorScheme.onBackground,
          ),
        );
      },
    );

    if (_passController.text != _confirmpassController.text) {
      Navigator.pop(context);
      showErrorBox('Passwords Dont Match');
      return;
    }

    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: _emailController.text, password: _passController.text);

      FirebaseFirestore.instance
          .collection(UserPersonalFirebase)
          .doc(userCredential.user!.email)
          .set({
        UsernameFirebase: _emailController.text.split('@')[0],
        UserBioFirebase: 'empty bio',
      });

      if (context.mounted) Navigator.pop(context);
    } on FirebaseAuthException catch (error) {
      Navigator.pop(context);
      showErrorBox(error.code);
    }
  }

  void showErrorBox(String error) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.onBackground,
          title: Center(child: Text(error)),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/logotemp.png'),
                  Text(
                    "STREAMS",
                    style: GoogleFonts.cedarvilleCursive(
                        color: Theme.of(context).colorScheme.onBackground,
                        fontSize: 25),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  CustomTextField(
                    isPass: false,
                    hintText: 'Email',
                    textEditingController: _emailController,
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  CustomTextField(
                    isPass: true,
                    hintText: 'Password',
                    textEditingController: _passController,
                  ),
                  const SizedBox(
                    height: 12,
                  ),
                  CustomTextField(
                    isPass: true,
                    hintText: 'Confirm Password',
                    textEditingController: _confirmpassController,
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  CustomButton(text: 'Register', onTap: signUp),
                  const SizedBox(
                    height: 30,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Already a member?',
                        style: TextStyle(color: Colors.grey.shade700),
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      GestureDetector(
                        onTap: widget.onTap,
                        child: Text(
                          'Login now',
                          style: TextStyle(
                              color:
                                  Theme.of(context).colorScheme.onBackground),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
