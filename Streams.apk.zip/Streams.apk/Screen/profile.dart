import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:streams/helpers/constants.dart';
import 'package:streams/widgets/details_box.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  User currentUser = FirebaseAuth.instance.currentUser!;

  CollectionReference userCollection =
      FirebaseFirestore.instance.collection(UserPersonalFirebase);

  Future<void> editDetails(String value) async {
    String newValue = '';

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.grey.shade900,
          title: Text(
            'Edit ${value}',
            style: TextStyle(color: Colors.white),
          ),
          content: TextField(
            style: TextStyle(color: Colors.white),
            autofocus: true,
            decoration: InputDecoration(
                enabled: true,
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade300)),
                hintText: 'Enter new $value',
                hintStyle: const TextStyle(color: Colors.grey)),
            onChanged: (v) {
              newValue = v;
            },
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(newValue),
                child: Text(
                  'Save',
                  style: TextStyle(color: Colors.grey.shade300),
                )),
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Cancel',
                  style: TextStyle(color: Colors.grey.shade300),
                )),
          ],
        );
      },
    );

    if (newValue.trim().isNotEmpty) {
      await userCollection.doc(currentUser.email).update({
        value: newValue,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: const Text(
          'My Profile',
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance
              .collection(UserPersonalFirebase)
              .doc(currentUser.email)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              final userdata = snapshot.data!.data() as Map<String, dynamic>;

              return ListView(children: [
                const SizedBox(
                  height: 40,
                ),
                Image.asset(
                  'assets/logotemp.png',
                  height: 200,
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  currentUser.email!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.onPrimary,
                      fontSize: 20),
                ),
                const SizedBox(
                  height: 50,
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                  child: Text(
                    'My Details',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Theme.of(context).colorScheme.onBackground,
                        fontSize: 18),
                  ),
                ),
                DetailsBox(
                    title: 'Username',
                    text: userdata[UsernameFirebase],
                    changeDetails: () => editDetails(UsernameFirebase)),
                DetailsBox(
                    title: 'Bio',
                    text: userdata[UserBioFirebase],
                    changeDetails: () => editDetails(UserBioFirebase)),
                const SizedBox(
                  height: 40,
                ),
                Padding(
                  padding: const EdgeInsets.all(25.0),
                  child: Text(
                    'My Posts',
                    style: TextStyle(
                        color: Theme.of(context).colorScheme.onBackground),
                  ),
                ),
              ]);
            } else if (snapshot.hasError) {
              return Center(
                child: Text('ERROR : ${snapshot.error.toString()}'),
              );
            }
            return Center(
              child: CircularProgressIndicator(
                color: Theme.of(context).colorScheme.onBackground,
              ),
            );
          }),
    );
  }
}
