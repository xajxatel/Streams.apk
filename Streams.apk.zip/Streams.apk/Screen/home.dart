import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:streams/Screen/profile.dart';
import 'package:streams/helpers/constants.dart';
import 'package:streams/helpers/time_stamp.dart';

import 'package:streams/widgets/drawer.dart';
import 'package:streams/widgets/post_panel.dart';
import 'package:streams/widgets/text_field.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final User currentUser = FirebaseAuth.instance.currentUser!;
  final TextEditingController _messageController = TextEditingController();

  void signOut() async {
    await FirebaseAuth.instance.signOut();
  }

  void postMessage() async {
    if (_messageController.text.trim().isNotEmpty) {
      await FirebaseFirestore.instance.collection(UserDataFirebase).add({
        UserEmailFirebase: currentUser.email,
        UserMessageFirebase: _messageController.text,
        UserTimeStampFirebase: Timestamp.now(),
        UserLikesFirebase: [],
      });
    }

    _messageController.clear();
  }

  void goToprofile() {
    Navigator.pop(context);

    Navigator.push(context, MaterialPageRoute(
      builder: (context) {
        return const ProfileScreen();
      },
    ));
  }

  @override
  Widget build(BuildContext context) {
    String? email = currentUser.email;

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: const Text(
          'Streams',
        ),
        centerTitle: true,
      ),
      drawer: CustomDrawer(
        logOut: signOut,
        onProfileTap: goToprofile,
      ),
      body: Center(
        child: Column(
          children: [
            Expanded(
                child: StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection(UserDataFirebase)
                  .orderBy(UserTimeStampFirebase, descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  return ListView.builder(
                    itemCount: snapshot.data!.docs.length,
                    itemBuilder: (context, index) {
                      final post = snapshot.data!.docs[index];

                      return PostPanel(
                        date: setDate(post[UserTimeStampFirebase]),
                        message: post[UserMessageFirebase],
                        userEmail: post[UserEmailFirebase],
                        postId: post.id,
                        likes: List<String>.from(
                          post[UserLikesFirebase] ?? [],
                        ),
                      );
                    },
                  );
                } else if (snapshot.hasError) {
                  return Center(
                    child: Text('ERROR : ${snapshot.error}'),
                  );
                }
                return Center(
                  child: CircularProgressIndicator(
                    color: Theme.of(context).colorScheme.onBackground,
                  ),
                );
              },
            )),
            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Expanded(
                    child: CustomTextField(
                        isPass: false,
                        hintText: 'Post something',
                        textEditingController: _messageController),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  IconButton(
                      onPressed: postMessage,
                      icon: const Icon(Icons.arrow_circle_up))
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
