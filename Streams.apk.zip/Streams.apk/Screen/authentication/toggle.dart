import 'package:flutter/material.dart';
import 'package:streams/Screen/login.dart';
import 'package:streams/Screen/signup.dart';

class ToggleScreen extends StatefulWidget {
  const ToggleScreen({super.key});

  @override
  State<ToggleScreen> createState() => _ToggleScreenState();
}

class _ToggleScreenState extends State<ToggleScreen> {
  bool isLogin = true;

  void toggleScreen() {
    setState(() {
      isLogin = !isLogin;
    });
  }

  @override
  Widget build(BuildContext context) {
    return isLogin
        ? LoginScreen(onTap: toggleScreen)
        : SignupScreen(onTap: toggleScreen);
  }
}
