import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  final TextEditingController textEditingController;
  final bool isPass;
  final String hintText;

  const CustomTextField(
      {super.key,
      required this.isPass,
      required this.hintText,
      required this.textEditingController});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: textEditingController,
      obscureText: isPass,
      style: TextStyle(color: Theme.of(context).colorScheme.onBackground),
      cursorColor: Theme.of(context).colorScheme.onBackground,
      decoration: InputDecoration(
        contentPadding: const EdgeInsets.all(22),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(
            color: Theme.of(context).colorScheme.secondary,
          ),
        ),
        focusedBorder: const OutlineInputBorder(
            borderSide:
                BorderSide(color: Color.fromARGB(255, 26, 25, 25), width: 2.3)),
        hintText: hintText,
        hintStyle: TextStyle(color: Colors.grey.shade500),
        fillColor: Theme.of(context).colorScheme.primary,
        filled: true,
      ),
    );
  }
}
