import 'package:flutter/material.dart';

class LikeButton extends StatelessWidget {
  final bool isLiked;
  final void Function()? onTap;

  const LikeButton({super.key, required this.onTap, required this.isLiked});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Icon(
          isLiked ? Icons.favorite_rounded : Icons.favorite_outline_rounded,
          color: isLiked ? Colors.red : Colors.grey),
    );
  }
}
