import 'package:flutter/material.dart';

class CustomListTile extends StatelessWidget {
  final Icon icon;
  final String text;
  final Function()? onTap;
  const CustomListTile({super.key, required this.text, required this.icon , required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: icon,
      title: Text(
        text,
        style: TextStyle(color: Colors.grey.shade300),
      ),
    );
  }
}
