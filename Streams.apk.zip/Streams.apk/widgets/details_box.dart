import 'package:flutter/material.dart';

class DetailsBox extends StatelessWidget {
  final String title;
  final String text;
  final Function()? changeDetails;
  const DetailsBox(
      {super.key,
      required this.title,
      required this.text,
      required this.changeDetails});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary),
      padding: const EdgeInsets.only(bottom: 15, left: 15),
      margin: const EdgeInsets.only(left: 20, right: 20, top: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title,
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.onBackground)),
              IconButton(
                  onPressed: changeDetails, icon: const Icon(Icons.settings))
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Text(text,
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.onBackground)),
            ],
          ),
        ],
      ),
    );
  }
}
