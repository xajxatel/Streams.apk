import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:streams/helpers/constants.dart';
import 'package:streams/helpers/time_stamp.dart';
import 'package:streams/widgets/comment_button.dart';
import 'package:streams/widgets/comments.dart';
import 'package:streams/widgets/delete_button.dart';
import 'package:streams/widgets/like_button.dart';

class PostPanel extends StatefulWidget {
  final String message;
  final String userEmail;
  final String postId;
  final List<String> likes;
  final String date;

  const PostPanel({
    Key? key,
    required this.message,
    required this.userEmail,
    required this.postId,
    required this.likes,
    required this.date,
  }) : super(key: key);

  @override
  State<PostPanel> createState() => _PostPanelState();
}

class _PostPanelState extends State<PostPanel> {
  final currentUser = FirebaseAuth.instance.currentUser;
  final TextEditingController _commentController = TextEditingController();
  Stream<int>? commentCountStream;
  String? username;

  bool isLiked = false;

  @override
  void initState() {
    isLiked = widget.likes.contains(currentUser!.email);

    commentCountStream = FirebaseFirestore.instance
        .collection(UserDataFirebase)
        .doc(widget.postId)
        .collection(UserCommentsFirebase)
        .snapshots()
        .map((snapshot) => snapshot.docs.length);

    super.initState();
  }

  void toggleLike() {
    setState(() {
      isLiked = !isLiked;
    });

    DocumentReference postRef = FirebaseFirestore.instance
        .collection(UserDataFirebase)
        .doc(widget.postId);

    if (isLiked) {
      postRef.update({
        UserLikesFirebase: FieldValue.arrayUnion([currentUser!.email])
      });
    } else if (!isLiked) {
      postRef.update({
        UserLikesFirebase: FieldValue.arrayRemove([currentUser!.email])
      });
    }
  }

  void addComment(String commentText) async {
    if (commentText.trim().isEmpty) {
      return;
    }

    await FirebaseFirestore.instance
        .collection(UserDataFirebase)
        .doc(widget.postId)
        .collection(UserCommentsFirebase)
        .add({
      UserCommentsTextFirebase: commentText,
      UserCommentedByFirebase: currentUser!.email,
      UserCommentTimeFirebase: Timestamp.now(),
    });
  }

  void showCommentBox() async {
    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.primary,
          title: Text("Add Comment",
              style:
                  TextStyle(color: Theme.of(context).colorScheme.onBackground)),
          content: TextField(
            style: TextStyle(color: Theme.of(context).colorScheme.onBackground),
            autofocus: true,
            controller: _commentController,
            decoration: InputDecoration(
                enabled: true,
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade300)),
                hintText: 'Type here',
                hintStyle: const TextStyle(color: Colors.grey)),
          ),
          actions: [
            TextButton(
                onPressed: () {
                  addComment(_commentController.text);
                  Navigator.of(context).pop();
                  _commentController.clear();
                },
                child: Text(
                  'Post',
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.onBackground),
                )),
            TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _commentController.clear();
                },
                child: Text('Cancel',
                    style: TextStyle(
                        color: Theme.of(context).colorScheme.onBackground))),
          ],
        );
      },
    );
  }

  void deletePost() async {
    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Delete comment'),
          content: Text('Are you sure?'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context), child: Text("Cancel")),
            TextButton(
                onPressed: () async {
                  final commentData = await FirebaseFirestore.instance
                      .collection(UserDataFirebase)
                      .doc(widget.postId)
                      .collection(UserCommentsFirebase)
                      .get();

                  for (final comment in commentData.docs) {
                    await FirebaseFirestore.instance
                        .collection(UserDataFirebase)
                        .doc(widget.postId)
                        .collection(UserCommentsFirebase)
                        .doc(comment.id)
                        .delete();
                  }

                  FirebaseFirestore.instance
                      .collection(UserDataFirebase)
                      .doc(widget.postId)
                      .delete()
                      .then((value) => print("SUCCESS"))
                      .catchError((error) => print('ERROR : $error.code'));

                  if (context.mounted) Navigator.pop(context);
                },
                child: const Text('Delete'))
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 25),
      margin: const EdgeInsets.only(right: 25, left: 25, top: 25),
      decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary,
          borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    widget.message,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onBackground,
                      fontSize: 18.5,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.date,
                    style: TextStyle(
                        color: Theme.of(context).colorScheme.onSecondary)),
              ],
            ),
          ]),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Column(
                children: [
                  LikeButton(onTap: toggleLike, isLiked: isLiked),
                  const SizedBox(
                    height: 5,
                  ),
                  Text(
                    widget.likes.length.toString(),
                    style: const TextStyle(color: Colors.grey),
                  ),
                ],
              ),
              const SizedBox(
                width: 10,
              ),
              Column(
                children: [
                  CommentButton(onTap: showCommentBox),
                  const SizedBox(
                    height: 5,
                  ),
                  StreamBuilder<int>(
                    stream: commentCountStream,
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return Center(
                          child: CircularProgressIndicator(
                            color: Theme.of(context).colorScheme.onBackground,
                          ),
                        );
                      }
                      return Text(
                        snapshot.data.toString(),
                        style: const TextStyle(color: Colors.grey),
                      );
                    },
                  ),
                ],
              ),
              const Spacer(),
              if (widget.userEmail == currentUser!.email)
                DeleteButton(onTap: deletePost)
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection(UserDataFirebase)
                  .doc(widget.postId)
                  .collection(UserCommentsFirebase)
                  .orderBy(UserCommentTimeFirebase, descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return Center(
                    child: CircularProgressIndicator(
                      color: Theme.of(context).colorScheme.onBackground,
                    ),
                  );
                }
                return ListView(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: snapshot.data!.docs.map((commentData) {
                    final comment = commentData.data() as Map<String, dynamic>;

                    return Comment(
                        text: comment[UserCommentsTextFirebase],
                        user: comment[UserCommentedByFirebase],
                        time: setDate(comment[UserCommentTimeFirebase]));
                  }).toList(),
                );
              })
        ],
      ),
    );
  }
}
