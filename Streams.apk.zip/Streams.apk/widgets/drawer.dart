import 'package:flutter/material.dart';
import 'package:streams/widgets/list_tile.dart';

class CustomDrawer extends StatelessWidget {
  final Function()? onProfileTap;
  final Function()? logOut;

  const CustomDrawer(
      {super.key, required this.onProfileTap, required this.logOut});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      shadowColor: Theme.of(context).colorScheme.onBackground,
      backgroundColor: Theme.of(context).colorScheme.background,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              DrawerHeader(
                child: Image.asset('assets/logotemp.png'),
              ),
              CustomListTile(
                onTap: () => Navigator.pop(context),
                text: 'Go Home',
                icon: const Icon(
                  Icons.home,
                  color: Colors.white,
                ),
              ),
              CustomListTile(
                  onTap: onProfileTap,
                  text: 'My Profile',
                  icon: const Icon(
                    Icons.person,
                    color: Colors.white,
                  )),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: CustomListTile(
                onTap: logOut,
                text: 'Log Out',
                icon: const Icon(
                  Icons.logout,
                  color: Colors.white,
                )),
          ),
        ],
      ),
    );
  }
}
