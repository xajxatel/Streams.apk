import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

ThemeData lightTheme = ThemeData(
    colorScheme: ColorScheme.light(
      background: Colors.white,
      primary: Colors.grey.shade200,
      secondary: Colors.grey.shade300,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.white,
      iconTheme: IconThemeData(color: Colors.black),
      titleTextStyle:
          GoogleFonts.cedarvilleCursive(color: Colors.black, fontSize: 27),
    ),
    brightness: Brightness.light,
    textTheme: GoogleFonts.cabinTextTheme(),
    useMaterial3: true);
