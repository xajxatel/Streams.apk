import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    colorScheme: ColorScheme.dark(
      background: Colors.black,
      primary: Colors.grey.shade900,
      secondary: Colors.grey.shade800,
      tertiary: Colors.grey.shade700,
      onBackground: Colors.white,
      onPrimary: Colors.grey.shade200,
      onSecondary: Colors.grey.shade400,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.black,
      iconTheme: IconThemeData(color: Colors.grey.shade300),
      titleTextStyle:
          GoogleFonts.cedarvilleCursive(color: Colors.white, fontSize: 27),
    ),
    textTheme: GoogleFonts.cabinTextTheme(),
    useMaterial3: true);
