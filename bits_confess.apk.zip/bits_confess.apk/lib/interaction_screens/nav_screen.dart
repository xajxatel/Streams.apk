// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

import 'package:bitsconfess/helpers/utils.dart';
import 'package:bitsconfess/interaction_screens/confessions.dart';
import 'package:bitsconfess/interaction_screens/home.dart';
import 'package:bitsconfess/interaction_screens/profile.dart';
import 'package:bitsconfess/interaction_screens/settings.dart';

class NavScreen extends StatefulWidget {
  final String? username;
  const NavScreen({
    Key? key,
    required this.username,
  }) : super(key: key);

  @override
  State<NavScreen> createState() => _NavScreenState();
}

class _NavScreenState extends State<NavScreen> {
  final PageController _pageController = PageController();
  int selectedIndex = 0;

  void setIndex(int index) {
    setState(() {
      selectedIndex = index;
      _pageController.jumpToPage(selectedIndex);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        centerTitle: true,
        title: AutoSizeText(
          'Confess',
          style: GoogleFonts.montez(color: Colors.purple, fontSize: 45),
          maxFontSize: 45,
          minFontSize: 15,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: PageView(
        onPageChanged: (index) {
          setState(() {
            selectedIndex = index;
          });
        },
        controller: _pageController,
        children: [
           HomeScreen(currentUsername: widget.username),
          const ConfessionsScreen(),
          ProfileScreen(username: widget.username , currentUsername: widget.username),
          const SettingsScreen(),
        ],
      ),
      bottomNavigationBar: Container(
        color: blackColor,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: GNav(
              color: whiteColor,
              tabBackgroundColor: Colors.grey.shade900,
              activeColor: Colors.grey.shade900,
              gap: 10,
              padding: const EdgeInsets.all(13.0),
              selectedIndex: selectedIndex,
              tabs: [
                GButton(
                  onPressed: () => setIndex(0),
                  iconActiveColor: whiteColor,
                  activeBorder: Border.all(color: Colors.purple, width: 2),
                  textStyle:
                      GoogleFonts.anonymousPro(fontSize: 20, color: whiteColor),
                  icon: Icons.home,
                  text: 'Home',
                ),
                GButton(
                  onPressed: () => setIndex(1),
                  iconActiveColor: whiteColor,
                  activeBorder: Border.all(color: Colors.purple, width: 2),
                  textStyle:
                      GoogleFonts.anonymousPro(fontSize: 20, color: whiteColor),
                  icon: Icons.edit,
                  text: 'Write',
                ),
                GButton(
                  onPressed: () => setIndex(2),
                  iconActiveColor: whiteColor,
                  activeBorder: Border.all(color: Colors.purple, width: 2),
                  textStyle:
                      GoogleFonts.anonymousPro(fontSize: 20, color: whiteColor),
                  icon: Icons.person,
                  text: 'Profile',
                ),
                GButton(
                  onPressed: () => setIndex(3),
                  iconActiveColor: whiteColor,
                  activeBorder: Border.all(color: Colors.purple, width: 2),
                  textStyle:
                      GoogleFonts.anonymousPro(fontSize: 20, color: whiteColor),
                  icon: Icons.settings,
                  text: 'Settings',
                ),
              ]),
        ),
      ),
    );
  }
}
