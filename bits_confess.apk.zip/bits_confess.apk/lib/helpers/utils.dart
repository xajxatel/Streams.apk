import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

//COLORS
const Color blackColor = Colors.black;
const Color whiteColor = Colors.white;
const Color purpleColor = Color.fromARGB(216, 155, 39, 176);

//UTILTY FUNCTIONS

Size getUserScreenSize(BuildContext context) {
  return MediaQuery.of(context).size;
}

void showSnackBar({required BuildContext context, required String content}) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
    content,
    style: GoogleFonts.anonymousPro(fontSize: 15),
  )));
}

String formatRelativeTime(DateTime timeSent) {
  final now = DateTime.now();
  final difference = now.difference(timeSent);

  if (difference.inSeconds < 60) {
    return '${difference.inSeconds} s';
  } else if (difference.inMinutes < 60) {
    return '${difference.inMinutes} m';
  } else if (difference.inHours < 24) {
    return '${difference.inHours} h';
  } else if (difference.inDays == 1) {
    return '1d';
  } else {
    return '${difference.inDays} d';
  }
}
